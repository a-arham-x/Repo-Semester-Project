package com;

import java.awt.Color;

import javax.swing.*;

public class ProjectFrame  extends JFrame{
    JTextField admin_login_textfield;
    JLabel enter_admin_key;
    JButton back_button;
    ProjectFrame(){
        this.setSize(1000, 670);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(new Color(210, 105, 30));

        this.setVisible(true);
    }

}

