package com;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JFrame implements ActionListener, MouseListener{
    LoginWindowPanel loginWindowPanel;
    LargeLabel openning_label;
    ProjectTextfield username_login_textfield;
    JPasswordField password_login_textfield;
    SmallButton loginButton;
    JButton show_hide_login_password;
    ImageIcon icon1;
    ImageIcon icon2;
    JButton settings_button;
    boolean password_visible = false;
    Timer timer;
    boolean sliding = false;
    boolean reverse_sliding = false;
    int slide_x=-140;
    int label_x = 145;
    boolean shifting_page = false;
    JLabel enter_admin_key;
    JPasswordField admin_key_textfield;
    JButton show_hide_admin_key;
    ImageIcon icon3;
    ImageIcon icon4;
    boolean admin_key_visible = false;
    JButton admin_login_button;
    int admin_slide_x=-140;
    boolean admin_settings_sliding = false;
    boolean admin_settings_reverse_sliding = false;
    boolean shifting_in_admin_account = false;
    boolean not_logged_in = true;
    boolean admin_logged_in = false;
    //Blob admin_profile_pic_blob;
    ImageIcon admin_profile_pic_icon;
    JLabel admin_profile_pic_label;
    JLabel admin_name;
    JLabel lms_admin_account;
    int admin_filling_y = 800;
    boolean logging_in_admin_account = false;
    boolean logging_out_admin_account = false;
    EnlongedButton admin_page_requests_button;
    EnlongedButton admin_page_catalogue_button;
    EnlongedButton admin_page_attendance_button;
    JPanel admin_home_page_panel;
    Main(){
        this.setSize(1000, 670);
        this.addMouseListener(this);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.white);

        settings_button = new JButton("⁞");
        settings_button.addActionListener(this);
        settings_button.setFocusable(false);
        settings_button.setBackground(new Color(148, 0, 211));
        settings_button.setForeground(Color.white);
        settings_button.setFont(new Font("Arial", Font.BOLD, 15));
        settings_button.setBounds(0, 0, 40, 40);
        this.add(settings_button);

        loginWindowPanel = new LoginWindowPanel();
        this.add(loginWindowPanel);

        openning_label = new LargeLabel("Library Management System", label_x, 20);
        this.add(openning_label);

        username_login_textfield = new ProjectTextfield(185, 150);
        loginWindowPanel.add(username_login_textfield);

        password_login_textfield = new JPasswordField();
        password_login_textfield.setFont(new Font("Arial", Font.PLAIN, 20));
        password_login_textfield.setBounds(185, 250, 300, 30);
        password_login_textfield.setEchoChar('●');
        loginWindowPanel.add(password_login_textfield);

        loginButton = new SmallButton("LogIn", 285, 310);
        loginWindowPanel.add(loginButton);

        icon1 = new ImageIcon("eyes to be used (2).png");
        icon2 = new ImageIcon("eyes to be used (3).png");
        show_hide_login_password = new JButton();
        show_hide_login_password.setIcon(icon1);
        show_hide_login_password.setForeground(Color.white);
        show_hide_login_password.addActionListener(this);
        show_hide_login_password.setFocusable(false);
        show_hide_login_password.setBounds(485, 250, 30, 30);
        loginWindowPanel.add(show_hide_login_password);

        enter_admin_key = new JLabel("Enter Admin Key");
        enter_admin_key.setBounds(300, 100, 400, 100);
        enter_admin_key.setFont(new Font("Arial", Font.BOLD, 50));
        enter_admin_key.setForeground(new Color(148, 0, 211));
        this.add(enter_admin_key);
        enter_admin_key.setVisible(false);

        admin_key_textfield = new JPasswordField();
        admin_key_textfield.setFont(new Font("Arial", Font.BOLD, 40));
        admin_key_textfield.setEchoChar('●');
        admin_key_textfield.setBounds(200, 220, 600, 100);
        admin_key_textfield.setBackground(new Color(245, 222, 179));
        this.add(admin_key_textfield);
        admin_key_textfield.setVisible(false);

        icon3 = new ImageIcon("Show or Hide Admin Key (4).png");
        icon4 = new ImageIcon("Show or Hide Admin Key (3).png");

        show_hide_admin_key = new JButton(icon3);
        show_hide_admin_key.setBounds(800, 220, 110, 100);
        show_hide_admin_key.setFocusable(false);
        show_hide_admin_key.addActionListener(this);
        this.add(show_hide_admin_key);
        show_hide_admin_key.setVisible(false);

        admin_login_button = new JButton("LogIn");
        admin_login_button.setForeground(Color.white);
        admin_login_button.setBackground(new Color(148, 0, 211));
        admin_login_button.setFocusable(false);
        admin_login_button.addActionListener(this);
        admin_login_button.setBounds(400, 350, 200, 100);
        admin_login_button.setFont(new Font("Arial", Font.BOLD, 40));
        this.add(admin_login_button);
        admin_login_button.setVisible(false);

        admin_home_page_panel = new JPanel();
        admin_home_page_panel.setBounds(200, 50, 650, 550);
        admin_home_page_panel.setBackground(new Color(245, 222, 179));
        admin_home_page_panel.setLayout(null);
        this.add(admin_home_page_panel);
        admin_home_page_panel.setVisible(false);

        admin_profile_pic_label = new JLabel();
        admin_profile_pic_label.setBounds(200, 50, 200, 150);
        admin_home_page_panel.add(admin_profile_pic_label);

        admin_name = new JLabel();
        admin_name.setForeground(new Color(148, 0, 211));
        admin_name.setFont(new Font("Arial", Font.BOLD, 20));
        admin_name.setBounds(230, 220, 140, 30);
        admin_home_page_panel.add(admin_name);

        lms_admin_account = new JLabel("Library Management System - Admin Account");
        lms_admin_account.setForeground(new Color(148, 0, 211));
        lms_admin_account.setBounds(100, 250, 450, 30);
        lms_admin_account.setFont(new Font("Arial", Font.BOLD, 20));
        admin_home_page_panel.add(lms_admin_account);

        admin_page_requests_button = new EnlongedButton("Requests", 50, 380);
        admin_home_page_panel.add(admin_page_requests_button);

        admin_page_catalogue_button = new EnlongedButton("Catalogue", 250, 380);
        admin_home_page_panel.add(admin_page_catalogue_button);

        admin_page_attendance_button = new EnlongedButton("Attendance", 450, 380);
        admin_home_page_panel.add(admin_page_attendance_button);

        this.setVisible(true);

        timer = new Timer(1, this);
        timer.start();
    }

    public static void main(String[] args) {
        new Main();
    }

    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.setPaint(new Color(148, 0, 211));
        g2D.drawRect(slide_x, 75, 140, 600);
        g2D.fillRect(slide_x, 70, 140, 600);
        g2D.setPaint(Color.white);
        g2D.setFont(new Font("Arial", Font.BOLD, 20));
        g2D.drawString("About", slide_x+20, 90);
        g2D.drawString("LogIn", slide_x + 20, 120);
        g2D.drawString("Credits", slide_x+20, 150);
        g2D.drawString("Admin", slide_x+20, 180);
        g2D.setPaint(new Color(148, 0, 211));
        g2D.drawRect(admin_slide_x, 75, 140, 600);
        g2D.fillRect(admin_slide_x, 70, 140, 600);
        g2D.setPaint(Color.white);
        g2D.drawString("Employees", admin_slide_x+20, 90);
        g2D.drawString("Members", admin_slide_x + 20, 120);
        g2D.drawString("Settings", admin_slide_x+20, 150);
        g2D.drawString("LogOut", admin_slide_x+20, 180);
        g2D.setPaint(new Color(148, 0, 211));
        g2D.drawRect(0, admin_filling_y, 1000, 30);
        g2D.fillRect(0, admin_filling_y, 1000, 30);
    }

    public void move_to_admin_login(){
        shifting_page = true;
        enter_admin_key.setVisible(true);
        admin_key_textfield.setVisible(true);
        show_hide_admin_key.setVisible(true);
        admin_login_button.setVisible(true);
        openning_label.setVisible(false);
        loginWindowPanel.setVisible(false);
        username_login_textfield.setText("");
        password_login_textfield.setText("");
    }

    public void move_to_login_page(){
        if (slide_x==0){
            shifting_page = true;
        }
        enter_admin_key.setVisible(false);
        admin_key_textfield.setVisible(false);
        show_hide_admin_key.setVisible(false);
        admin_login_button.setVisible(false);
        admin_key_textfield.setText("");
        openning_label.setVisible(true);
        loginWindowPanel.setVisible(true);
    }

    public void admin_login(){
        AdminCredentials adminCredentials = new AdminCredentials();
        if (String.valueOf(admin_key_textfield.getPassword()).equals(adminCredentials.getAdmin_key())){
            open_admin_account();
        }else{
            new IncorrectAdminKeyFrame();
        }
    }

    public void open_admin_account(){
        not_logged_in = false;
        admin_logged_in = true;
        logging_in_admin_account = true;
        AdminProfilePic adminProfilePic = new AdminProfilePic();
        admin_profile_pic_icon = adminProfilePic.getAdmin_prof();
        admin_profile_pic_label.setIcon(admin_profile_pic_icon);
        AdminCredentials adminCredentials = new AdminCredentials();
        admin_name.setText(adminCredentials.getAdmin_name());
        admin_home_page_panel.setVisible(true);
        enter_admin_key.setVisible(false);
        admin_key_textfield.setVisible(false);
        show_hide_admin_key.setVisible(false);
        admin_key_textfield.setText("");
        admin_login_button.setVisible(false);
    }

    public void logout_admin_account(){
        shifting_in_admin_account = true;
        logging_out_admin_account = true;
        admin_home_page_panel.setVisible(false);
        admin_logged_in = false;
        not_logged_in = true;
        move_to_login_page();
    }

    public void actionPerformed(ActionEvent e){
        if (sliding){
            repaint();
            slide_x += 2;
        }if (slide_x>-1){
            sliding = false;
        }if (reverse_sliding){
            repaint();
            slide_x -= 2;
        }if (slide_x==-140){
            reverse_sliding = false;
        }if (shifting_page){
            repaint();
            slide_x -= 140;
            shifting_page = false;
        }if (admin_settings_sliding){
            repaint();
            admin_slide_x += 2;
        }if (admin_slide_x==0){
            admin_settings_sliding = false;
        }if (admin_settings_reverse_sliding){
            repaint();
            admin_slide_x -= 2;
        }if (admin_slide_x==-140){
            admin_settings_reverse_sliding = false;
        }if (shifting_in_admin_account){
            repaint();
            admin_slide_x -= 140;
            shifting_in_admin_account = false;
        }if (logging_in_admin_account){
            repaint();
            admin_filling_y = 650;
            logging_in_admin_account = false;
        }if (logging_out_admin_account){
            repaint();
            admin_filling_y = 800;
            logging_out_admin_account = false;
        }
        if (e.getSource()==show_hide_login_password){
            if (password_visible){
                show_hide_login_password.setIcon(icon1);
                password_login_textfield.setEchoChar('●');
                password_visible = false;
            }else {
                show_hide_login_password.setIcon(icon2);
                password_login_textfield.setEchoChar((char) 0);
                password_visible = true;
            }
        }if (e.getSource()==settings_button){
            if (not_logged_in) {
                if (slide_x==-140){
                    sliding = true;
                }else if (slide_x==0){
                    reverse_sliding = true;
                }
            }if (admin_logged_in){
                if (admin_slide_x==-140){
                    admin_settings_sliding = true;
                }else{
                    admin_settings_reverse_sliding = true;
                }
            }
        }if (e.getSource()==show_hide_admin_key) {
            if (admin_key_visible) {
                admin_key_textfield.setEchoChar('●');
                admin_key_visible = false;
                show_hide_admin_key.setIcon(icon3);
            } else {
                admin_key_textfield.setEchoChar((char) 0);
                admin_key_visible = true;
                show_hide_admin_key.setIcon(icon4);
            }
        }if (e.getSource()==admin_login_button) {
            admin_login();
        }
    }

    public void mousePressed(MouseEvent e) {
        if (slide_x>-1 && e.getX()<141){
            if (e.getY()>60 && e.getY()<90){
                System.out.println("About");
            }else if (e.getY()>90 && e.getY()<120){
                move_to_login_page();
            }else if (e.getY()>120 && e.getY()<150){
                System.out.println("Credits");
            }else if (e.getY()>150 && e.getY()<180){
                move_to_admin_login();
            }
        }if (admin_slide_x==0 && e.getX()<141){
            if (e.getY()>60 && e.getY()<90){
                System.out.println("Employees");
            }else if (e.getY()>90 && e.getY()<120){
                System.out.println("Members");
            }else if (e.getY()>120 && e.getY()<150){
                System.out.println("Settings");
            }else if (e.getY()>150 && e.getY()<180){
                logout_admin_account();
            }
        }if (admin_profile_pic_label.isVisible()){
            if (e.getX()>400 && e.getX()<600 && e.getY()>100 && e.getY()<250){
                new AdminProfileSetFrame();
            }
        }
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {
    }
    public void mouseClicked(MouseEvent e){
    }
}
