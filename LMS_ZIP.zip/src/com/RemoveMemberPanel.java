package com;

public class RemoveMemberPanel extends AddMemberPanel{
}
