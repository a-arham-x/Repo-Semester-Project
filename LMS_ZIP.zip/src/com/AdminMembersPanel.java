package com;

import javax.swing.*;
import java.awt.*;

public class AdminMembersPanel extends JPanel{
    AdminMembersPanel(){
        this.setBounds(160, 70, 650, 470);
        this.setBackground(new Color(245, 222, 179));
        this.setLayout(null);
    }

}
