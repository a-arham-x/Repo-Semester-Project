package com;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class AdminMain extends JFrame implements ActionListener, MouseListener, KeyListener{
    JLabel enter_admin_key;
    JPasswordField admin_key_textfield;
    JButton show_hide_admin_key;
    ImageIcon icon1;
    ImageIcon icon2;
    ImageIcon icon3;
    ImageIcon icon4;
    Timer timer;
    boolean admin_key_visible = false;
    JButton admin_login_button;
    JButton admin_settings_button;
    int admin_slide_x=-140;
    boolean admin_settings_sliding = false;
    boolean admin_settings_reverse_sliding = false;
    boolean shifting_in_admin_account = false;
    ImageIcon admin_profile_pic_icon;
    JLabel admin_profile_pic_label;
    JLabel admin_name;
    JLabel lms_admin_account;
    JButton refresh_admin_page;
    EnlongedButton admin_page_requests_button;
    EnlongedButton admin_page_catalogue_button;
    EnlongedButton admin_page_attendance_button;
    JPanel admin_home_page_panel;
    JPanel admin_info_panel;
    JLabel admin_update_name_label;
    JLabel admin_update_key_label;
    JLabel admin_update_new_key_label;
    JTextField admin_update_name_textfield;
    JPasswordField admin_update_key_textfield;
    JPasswordField admin_update_new_key_textfield;
    JButton admin_info_update;
    JButton admin_info_key_show_hide_button;
    JButton admin_info_new_key_show_hide_button;
    boolean admin_key_info_visible = false;
    boolean admin_new_key_visible = false;
    AdminMembersPanel adminMembersPanel;
    LargerEnlongedButton admin_add_member;
    LargerEnlongedButton admin_remove_member;
    LargerEnlongedButton admin_view_members;
    AddMemberPanel addMemberPanel;
    SmallLabel add_member_name_label;
    SmallLabel add_member_username_label;
    SmallLabel add_member_password_label;
    SmallLabel add_member_age_label;
    SmallLabel add_member_gender_label;
    SmallLabel add_member_phone_label;
    SmallLabel add_member_email_label;
    ProjectTextfield add_member_name_textfield;
    ProjectTextfield add_member_username_textfield;
    ProjectTextfield add_member_password_textfield;
    ProjectTextfield add_member_age_textfield;
    JComboBox<String> add_member_gender_combobox;
    ProjectTextfield add_member_phone_textfield;
    ProjectTextfield add_member_email_textfield;
    SmallButton add_member_button;
    RemoveMemberPanel removeMemberPanel;
    SmallLabel remove_member_username_label;
    //SmallLabel remove_member_password_label;
    ProjectTextfield remove_member_username_textfield;
    //ProjectTextfield remove_member_password_textfield;
    EnlongedButton remove_member_button;
    LargeLabel delete_member_account;
    ViewMembersPanel viewMembersPanel;
    JButton vmp_scroll_up;
    JButton vmp_scroll_down;
    JButton vmp_scroll_left;
    JButton vmp_scroll_right;
    SearchButton search_member;
    boolean searching_member = false;
    JPanel search_panel;
    ProjectTextfield search_member_textfield;
    JPanel admin_employee_panel;
    LargerEnlongedButton admin_add_employee;
    LargerEnlongedButton admin_remove_employee;
    LargerEnlongedButton admin_view_employees;
    ViewAMemberPanel viewAMemberPanel;
    EnlongedButton back_from_vamp;
    JPanel addEmployeePanel;
    SmallLabel add_employee_name_label;
    SmallLabel add_employee_username_label;
    SmallLabel add_employee_password_label;
    SmallLabel add_employee_age_label;
    SmallLabel add_employee_gender_label;
    SmallLabel add_employee_job_label;
    SmallLabel add_employee_phone_label;
    SmallLabel add_employee_email_label;
    ProjectTextfield add_employee_name_textfield;
    ProjectTextfield add_employee_username_textfield;
    ProjectTextfield add_employee_password_textfield;
    ProjectTextfield add_employee_age_textfield;
    JComboBox<String> add_employee_gender_combobox;
    ProjectTextfield add_employee_job_textfield;
    ProjectTextfield add_employee_phone_textfield;
    ProjectTextfield add_employee_email_textfield;
    EnlongedButton add_employee_button;
    JPanel remove_employee_panel;
    AdminMain(){
        this.setSize(1000, 670);
        this.addMouseListener(this);
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.white);
        this.addKeyListener(this);

        enter_admin_key = new JLabel("Enter Admin Key");
        enter_admin_key.setBounds(300, 100, 400, 100);
        enter_admin_key.setFont(new Font("Arial", Font.BOLD, 50));
        enter_admin_key.setForeground(new Color(148, 0, 211));
        this.add(enter_admin_key);

        admin_key_textfield = new JPasswordField();
        admin_key_textfield.setFont(new Font("Arial", Font.BOLD, 40));
        admin_key_textfield.setEchoChar('●');
        admin_key_textfield.setBounds(200, 220, 600, 100);
        admin_key_textfield.setBackground(new Color(245, 222, 179));
        this.add(admin_key_textfield);

        icon1 = new ImageIcon("eyes to be used (2).png");
        icon2 = new ImageIcon("eyes to be used (3).png");
        icon3 = new ImageIcon("Show or Hide Admin Key (4).png");
        icon4 = new ImageIcon("Show or Hide Admin Key (3).png");

        show_hide_admin_key = new JButton(icon3);
        show_hide_admin_key.setBounds(800, 220, 110, 100);
        show_hide_admin_key.setFocusable(false);
        show_hide_admin_key.addActionListener(this);
        this.add(show_hide_admin_key);

        admin_login_button = new JButton("LogIn");
        admin_login_button.setForeground(Color.white);
        admin_login_button.setBackground(new Color(148, 0, 211));
        admin_login_button.setFocusable(false);
        admin_login_button.addActionListener(this);
        admin_login_button.setBounds(400, 350, 200, 100);
        admin_login_button.setFont(new Font("Arial", Font.BOLD, 40));
        this.add(admin_login_button);

        admin_settings_button = new JButton("⁞");
        admin_settings_button.addActionListener(this);
        admin_settings_button.setFocusable(false);
        admin_settings_button.setBackground(new Color(148, 0, 211));
        admin_settings_button.setForeground(Color.white);
        admin_settings_button.setFont(new Font("Arial", Font.BOLD, 15));
        admin_settings_button.setBounds(0, 0, 40, 40);
        this.add(admin_settings_button);
        admin_settings_button.setVisible(false);

        admin_home_page_panel = new JPanel();
        admin_home_page_panel.setBounds(200, 50, 650, 550);
        admin_home_page_panel.setBackground(new Color(245, 222, 179));
        admin_home_page_panel.setLayout(null);
        this.add(admin_home_page_panel);
        admin_home_page_panel.setVisible(false);

        ImageIcon refresh_icon = new ImageIcon("refresh.png");
        refresh_admin_page = new JButton(refresh_icon);
        refresh_admin_page.setBounds(945, 0, 40, 40);
        refresh_admin_page.addActionListener(this);
        refresh_admin_page.setFocusable(false);
        this.add(refresh_admin_page);
        refresh_admin_page.setVisible(false);

        admin_profile_pic_label = new JLabel();
        admin_profile_pic_label.setBounds(200, 50, 200, 150);
        admin_home_page_panel.add(admin_profile_pic_label);

        admin_name = new JLabel();
        admin_name.setForeground(new Color(148, 0, 211));
        admin_name.setFont(new Font("Arial", Font.BOLD, 20));
        admin_name.setBounds(230, 220, 300, 30);
        admin_home_page_panel.add(admin_name);

        lms_admin_account = new JLabel("Library Management System - Admin Account");
        lms_admin_account.setForeground(new Color(148, 0, 211));
        lms_admin_account.setBounds(100, 250, 450, 30);
        lms_admin_account.setFont(new Font("Arial", Font.BOLD, 20));
        admin_home_page_panel.add(lms_admin_account);

        admin_page_requests_button = new EnlongedButton("Requests", 50, 380);
        admin_home_page_panel.add(admin_page_requests_button);

        admin_page_catalogue_button = new EnlongedButton("Catalogue", 250, 380);
        admin_home_page_panel.add(admin_page_catalogue_button);

        admin_page_attendance_button = new EnlongedButton("Attendance", 450, 380);
        admin_home_page_panel.add(admin_page_attendance_button);

        admin_info_panel = new JPanel();
        admin_info_panel.setBounds(200, 50, 650, 550);
        admin_info_panel.setBackground(new Color(245, 222, 179));
        admin_info_panel.setLayout(null);
        this.add(admin_info_panel);
        admin_info_panel.setVisible(false);

        admin_update_name_label = new JLabel("Name");
        admin_update_name_label.setForeground(Color.BLACK);
        admin_update_name_label.setFont(new Font("Arial", Font.BOLD, 30));
        admin_update_name_label.setBounds(60, 140, 100, 30);
        admin_info_panel.add(admin_update_name_label);

        admin_update_key_label = new JLabel("Old Key");
        admin_update_key_label.setForeground(Color.BLACK);
        admin_update_key_label.setFont(new Font("Arial", Font.BOLD, 30));
        admin_update_key_label.setBounds(60, 200, 140, 30);
        admin_info_panel.add(admin_update_key_label);

        admin_update_new_key_label = new JLabel("New Key");
        admin_update_new_key_label.setForeground(Color.BLACK);
        admin_update_new_key_label.setFont(new Font("Arial", Font.BOLD, 30));
        admin_update_new_key_label.setBounds(60, 260, 140, 30);
        admin_info_panel.add(admin_update_new_key_label);

        admin_update_name_textfield = new JTextField();
        admin_update_name_textfield.setBounds(200, 140, 300, 30);
        admin_update_name_textfield.setFont(new Font("Arial", Font.BOLD, 30));
        admin_update_name_textfield.setForeground(Color.BLACK);
        admin_info_panel.add(admin_update_name_textfield);

        admin_update_key_textfield = new JPasswordField();
        admin_update_key_textfield.setEchoChar('●');
        admin_update_key_textfield.setBounds(200, 200, 300, 30);
        admin_update_key_textfield.setFont(new Font("Arial", Font.BOLD, 30));
        admin_update_key_textfield.setForeground(Color.BLACK);
        admin_info_panel.add(admin_update_key_textfield);

        admin_update_new_key_textfield = new JPasswordField();
        admin_update_new_key_textfield.setEchoChar('●');
        admin_update_new_key_textfield.setBounds(200, 260, 300, 30);
        admin_update_new_key_textfield.setFont(new Font("Arial", Font.BOLD, 30));
        admin_update_new_key_textfield.setForeground(Color.BLACK);
        admin_info_panel.add(admin_update_new_key_textfield);

        admin_info_update = new JButton("UPDATE");
        admin_info_update.setBounds(200, 400, 200, 100);
        admin_info_update.setFont(new Font("Arial", Font.BOLD, 30));
        admin_info_update.setBackground(new Color(148, 0, 211));
        admin_info_update.setForeground(Color.white);
        admin_info_update.addActionListener(this);
        admin_info_update.setFocusable(false);
        admin_info_panel.add(admin_info_update);

        admin_info_key_show_hide_button = new JButton();
        admin_info_key_show_hide_button.setIcon(icon1);
        admin_info_key_show_hide_button.setForeground(Color.white);
        admin_info_key_show_hide_button.addActionListener(this);
        admin_info_key_show_hide_button.setFocusable(false);
        admin_info_key_show_hide_button.setBounds(500, 200, 30, 30);
        admin_info_panel.add(admin_info_key_show_hide_button);

        admin_info_new_key_show_hide_button = new JButton();
        admin_info_new_key_show_hide_button.setIcon(icon1);
        admin_info_new_key_show_hide_button.setForeground(Color.white);
        admin_info_new_key_show_hide_button.addActionListener(this);
        admin_info_new_key_show_hide_button.setFocusable(false);
        admin_info_new_key_show_hide_button.setBounds(500, 260, 30, 30);
        admin_info_panel.add(admin_info_new_key_show_hide_button);

        adminMembersPanel = new AdminMembersPanel();
        this.add(adminMembersPanel);
        adminMembersPanel.setVisible(false);

        admin_add_member = new LargerEnlongedButton("Add Member", 175, 40);
        admin_add_member.addActionListener(this);
        adminMembersPanel.add(admin_add_member);

        admin_remove_member = new LargerEnlongedButton("Remove Member", 175, 180);
        admin_remove_member.addActionListener(this);
        adminMembersPanel.add(admin_remove_member);

        admin_view_members = new LargerEnlongedButton("View Members", 175, 320);
        admin_view_members.addActionListener(this);
        adminMembersPanel.add(admin_view_members);

        addMemberPanel = new AddMemberPanel();
        this.add(addMemberPanel);
        addMemberPanel.setVisible(false);

        add_member_name_label = new SmallLabel("Name", 100, 20);
        addMemberPanel.add(add_member_name_label);

        add_member_username_label = new SmallLabel("Username", 100, 100);
        addMemberPanel.add(add_member_username_label);

        add_member_password_label = new SmallLabel("Password", 100, 180);
        addMemberPanel.add(add_member_password_label);

        add_member_gender_label = new SmallLabel("Gender", 300, 260);
        addMemberPanel.add(add_member_gender_label);

        add_member_age_label = new SmallLabel("Age", 400, 20);
        addMemberPanel.add(add_member_age_label);

        add_member_phone_label = new SmallLabel("Phone Number", 400, 100);
        addMemberPanel.add(add_member_phone_label);

        add_member_email_label = new SmallLabel("Email Address", 400, 180);
        addMemberPanel.add(add_member_email_label);

        add_member_name_textfield = new ProjectTextfield(10, 60);
        addMemberPanel.add(add_member_name_textfield);

        add_member_username_textfield = new ProjectTextfield(10, 140);
        addMemberPanel.add(add_member_username_textfield);

        add_member_password_textfield = new ProjectTextfield(10, 220);
        addMemberPanel.add(add_member_password_textfield);

        String[] genders = {"Male", "Female"};

        add_member_gender_combobox = new JComboBox<>(genders);
        add_member_gender_combobox.setBounds(200, 300, 300, 30);
        add_member_gender_combobox.setFont(new Font("Arial", Font.BOLD, 20));
        addMemberPanel.add(add_member_gender_combobox);

        add_member_age_textfield = new ProjectTextfield(350, 60);
        addMemberPanel.add(add_member_age_textfield);

        add_member_phone_textfield = new ProjectTextfield(350, 140);
        addMemberPanel.add(add_member_phone_textfield);

        add_member_email_textfield = new ProjectTextfield(350, 220);
        addMemberPanel.add(add_member_email_textfield);

        add_member_button = new SmallButton("ADD", 300, 380);
        add_member_button.addActionListener(this);
        add_member_button.setForeground(Color.white);
        add_member_button.setBackground(new Color(148, 0, 211));
        addMemberPanel.add(add_member_button);

        removeMemberPanel = new RemoveMemberPanel();
        this.add(removeMemberPanel);
        removeMemberPanel.setVisible(false);

        remove_member_username_label = new SmallLabel("Username", 300, 160);
        removeMemberPanel.add(remove_member_username_label);

        //remove_member_password_label = new SmallLabel("Password", 300, 200);
        //removeMemberPanel.add(remove_member_password_label);

        remove_member_username_textfield = new ProjectTextfield(200, 200);
        removeMemberPanel.add(remove_member_username_textfield);

        //remove_member_password_textfield = new ProjectTextfield(200, 240);
        //removeMemberPanel.add(remove_member_password_textfield);

        remove_member_button = new EnlongedButton("Remove", 275, 320);
        remove_member_button.addActionListener(this);
        removeMemberPanel.add(remove_member_button);

        delete_member_account = new LargeLabel("Delete Account", 175, 20);
        removeMemberPanel.add(delete_member_account);

        viewMembersPanel = new ViewMembersPanel();
        this.add(viewMembersPanel);
        viewMembersPanel.setVisible(false);

        vmp_scroll_up = new JButton("^");
        vmp_scroll_up.setBounds(435, 30, 100, 40);
        vmp_scroll_up.setForeground(Color.white);
        vmp_scroll_up.setBackground(new Color(148, 0, 211));
        vmp_scroll_up.setFont(new Font("Arial", Font.BOLD, 20));
        vmp_scroll_up.setFocusable(false);
        vmp_scroll_up.addActionListener(this);
        this.add(vmp_scroll_up);
        vmp_scroll_up.setVisible(false);

        vmp_scroll_down = new JButton("v");
        vmp_scroll_down.setBounds(435, 540, 100, 40);
        vmp_scroll_down.setForeground(Color.white);
        vmp_scroll_down.setBackground(new Color(148, 0, 211));
        vmp_scroll_down.setFont(new Font("Arial", Font.BOLD, 15));
        vmp_scroll_down.setFocusable(false);
        vmp_scroll_down.addActionListener(this);
        this.add(vmp_scroll_down);
        vmp_scroll_down.setVisible(false);

        vmp_scroll_right = new JButton(">");
        vmp_scroll_right.setBounds(810, 255, 60, 100);
        vmp_scroll_right.setForeground(Color.white);
        vmp_scroll_right.setBackground(new Color(148, 0, 211));
        vmp_scroll_right.setFont(new Font("Arial", Font.BOLD, 20));
        vmp_scroll_right.setFocusable(false);
        vmp_scroll_right.addActionListener(this);
        this.add(vmp_scroll_right);
        vmp_scroll_right.setVisible(false);

        vmp_scroll_left = new JButton("<");
        vmp_scroll_left.setBounds(100, 255, 60, 100);
        vmp_scroll_left.setForeground(Color.white);
        vmp_scroll_left.setBackground(new Color(148, 0, 211));
        vmp_scroll_left.setFont(new Font("Arial", Font.BOLD, 20));
        vmp_scroll_left.setFocusable(false);
        vmp_scroll_left.addActionListener(this);
        this.add(vmp_scroll_left);
        vmp_scroll_left.setVisible(false);

        search_member = new SearchButton(905, 0);
        search_member.addActionListener(this);
        this.add(search_member);
        search_member.setVisible(false);

        search_panel = new JPanel();
        search_panel.setBounds(585, 0, 320, 40);
        search_panel.setBackground(Color.BLUE);
        search_panel.setLayout(null);
        this.add(search_panel);
        search_panel.setVisible(false);

        search_member_textfield = new ProjectTextfield(10, 5);
        search_panel.add(search_member_textfield);

        admin_add_employee = new LargerEnlongedButton("Add Employee",5,5);
        admin_add_employee.addActionListener(this);
        admin_remove_employee = new LargerEnlongedButton("Remove Employee",5,5);
        admin_remove_employee.addActionListener(this);
        admin_view_employees = new LargerEnlongedButton("View Employees",5,5);
        admin_view_employees.addActionListener(this);

        admin_employee_panel = new JPanel();
        admin_employee_panel.setBounds(160, 70, 650, 470);
        admin_employee_panel.setBackground(new Color(245,222,179));
        admin_employee_panel.setLayout(new BoxLayout(admin_employee_panel,BoxLayout.Y_AXIS));
        admin_add_employee.setAlignmentX(Component.CENTER_ALIGNMENT);
        admin_remove_employee.setAlignmentX(Component.CENTER_ALIGNMENT);
        admin_view_employees.setAlignmentX(Component.CENTER_ALIGNMENT);
        admin_employee_panel.add(Box.createRigidArea(new Dimension(300,80)));
        admin_employee_panel.add(admin_add_employee);
        admin_employee_panel.add(Box.createRigidArea(new Dimension(300,80)));
        admin_employee_panel.add(admin_remove_employee);
        admin_employee_panel.add(Box.createRigidArea(new Dimension(300,80)));
        admin_employee_panel.add(admin_view_employees);
        this.add(admin_employee_panel);
        admin_employee_panel.setVisible(false);

        viewAMemberPanel = new ViewAMemberPanel();
        this.add(viewAMemberPanel);
        viewAMemberPanel.setVisible(false);

        back_from_vamp = new EnlongedButton("BACK", 10, 400);
        back_from_vamp.addActionListener(this);
        viewAMemberPanel.add(back_from_vamp);

        addEmployeePanel = new JPanel();
        addEmployeePanel.setBackground(new Color(245, 222, 179));
        addEmployeePanel.setBounds(150, 70, 670, 470);
        addEmployeePanel.setLayout(null);
        this.add(addEmployeePanel);
        addEmployeePanel.setVisible(false);

        add_employee_name_label = new SmallLabel("Name", 100, 20);
        addEmployeePanel.add(add_employee_name_label);

        add_employee_username_label = new SmallLabel("Username", 100, 100);
        addEmployeePanel.add(add_employee_username_label);

        add_employee_password_label = new SmallLabel("Password", 100, 180);
        addEmployeePanel.add(add_employee_password_label);

        add_employee_gender_label = new SmallLabel("Gender", 100, 260);
        addEmployeePanel.add(add_employee_gender_label);

        add_employee_age_label = new SmallLabel("Age", 400, 20);
        addEmployeePanel.add(add_employee_age_label);

        add_employee_job_label = new SmallLabel("Job", 400, 100);
        addEmployeePanel.add(add_employee_job_label);

        add_employee_phone_label = new SmallLabel("Phone Number", 400, 180);
        addEmployeePanel.add(add_employee_phone_label);

        add_employee_email_label = new SmallLabel("Email Address", 400, 260);
        addEmployeePanel.add(add_employee_email_label);

        add_employee_name_textfield = new ProjectTextfield(10, 60);
        addEmployeePanel.add(add_employee_name_textfield);

        add_employee_username_textfield = new ProjectTextfield(10, 140);
        addEmployeePanel.add(add_employee_username_textfield);

        add_employee_password_textfield = new ProjectTextfield(10, 220);
        addEmployeePanel.add(add_employee_password_textfield);

        add_employee_gender_combobox = new JComboBox<>(genders);
        add_employee_gender_combobox.setBounds(10, 300, 300, 30);
        add_employee_gender_combobox.setFont(new Font("Arial", Font.BOLD, 20));
        addEmployeePanel.add(add_employee_gender_combobox);

        add_employee_age_textfield = new ProjectTextfield(350, 60);
        addEmployeePanel.add(add_employee_age_textfield);

        add_employee_job_textfield = new ProjectTextfield(350, 140);
        addEmployeePanel.add(add_employee_job_textfield);

        add_employee_phone_textfield = new ProjectTextfield(350, 220);
        addEmployeePanel.add(add_employee_phone_textfield);

        add_employee_email_textfield = new ProjectTextfield(350, 300);
        addEmployeePanel.add(add_employee_email_textfield);

        add_employee_button = new EnlongedButton("ADD", 265, 370);
        add_employee_button.addActionListener(this);
        addEmployeePanel.add(add_employee_button);

        remove_employee_panel = new JPanel();
        remove_employee_panel.setBounds(160, 70, 650, 470);
        remove_employee_panel.setBackground(new Color(245, 222, 179));
        remove_employee_panel.setLayout(null);
        this.add(remove_employee_panel);
        remove_employee_panel.setVisible(false);


        this.setVisible(true);

        timer = new Timer(20, this);
        timer.start();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.setPaint(new Color(148, 0, 211));
        g2D.drawRect(admin_slide_x, 75, 140, 600);
        g2D.fillRect(admin_slide_x, 70, 140, 600);
        g2D.setPaint(Color.white);
        g2D.setFont(new Font("Arial", Font.BOLD, 20));
        g2D.drawString("Home", admin_slide_x+20, 90);
        g2D.drawString("Employees", admin_slide_x+20, 120);
        g2D.drawString("Members", admin_slide_x + 20, 150);
        g2D.drawString("Info", admin_slide_x+20, 180);
        g2D.drawString("LogOut", admin_slide_x+20, 210);

    }

    public static void main(String[] args){
        new AdminMain();
    }

    public void admin_login(){
        AdminCredentials adminCredentials = new AdminCredentials();
        if (String.valueOf(admin_key_textfield.getPassword()).equals(adminCredentials.getAdmin_key())){
            open_admin_account();
        }else{
            new IncorrectAdminKeyFrame();
        }
    }

    public void open_admin_account(){
        admin_slide_x = -140;
        repaint();
        admin_key_textfield.setEchoChar('●');
        show_hide_admin_key.setIcon(icon3);
        AdminProfilePic adminProfilePic = new AdminProfilePic();
        admin_profile_pic_icon = adminProfilePic.getAdmin_prof();
        admin_profile_pic_label.setIcon(admin_profile_pic_icon);
        AdminCredentials adminCredentials = new AdminCredentials();
        admin_name.setText(adminCredentials.getAdmin_name());
        refresh_admin_page.setVisible(true);
        admin_home_page_panel.setVisible(true);
        admin_settings_button.setVisible(true);
        addMemberPanel.setVisible(false);
        enter_admin_key.setVisible(false);
        admin_key_textfield.setVisible(false);
        show_hide_admin_key.setVisible(false);
        admin_login_button.setVisible(false);
        admin_info_panel.setVisible(false);
        adminMembersPanel.setVisible(false);
        removeMemberPanel.setVisible(false);
        admin_employee_panel.setVisible(false);
        viewAMemberPanel.setVisible(false);
        addEmployeePanel.setVisible(false);
        exit_viewMembersPanel();
        setTextFieldsNull();
    }

    public void move_to_admin_login(){
        enter_admin_key.setVisible(true);
        admin_key_textfield.setVisible(true);
        show_hide_admin_key.setVisible(true);
        admin_login_button.setVisible(true);
    }

    public void logout_admin_account(){
        shifting_in_admin_account = true;
        admin_info_panel.setVisible(false);
        admin_settings_button.setVisible(false);
        admin_home_page_panel.setVisible(false);
        refresh_admin_page.setVisible(false);
        adminMembersPanel.setVisible(false);
        addMemberPanel.setVisible(false);
        removeMemberPanel.setVisible(false);
        admin_employee_panel.setVisible(false);
        viewAMemberPanel.setVisible(false);
        addEmployeePanel.setVisible(false);
        exit_viewMembersPanel();
        setTextFieldsNull();
        move_to_admin_login();
    }

    public void move_to_admin_info_update(){
        adminMembersPanel.setVisible(false);
        addMemberPanel.setVisible(false);
        admin_home_page_panel.setVisible(false);
        exit_viewMembersPanel();
        admin_slide_x = -140;
        repaint();
        admin_info_panel.setVisible(true);
        removeMemberPanel.setVisible(false);
        admin_employee_panel.setVisible(false);
        viewAMemberPanel.setVisible(false);
        addEmployeePanel.setVisible(false);
        setTextFieldsNull();
    }

    public void open_admin_members_panel(){
        adminMembersPanel.setVisible(true);
        admin_home_page_panel.setVisible(false);
        exit_viewMembersPanel();
        admin_slide_x = -140;
        repaint();
        viewAMemberPanel.setVisible(false);
        admin_info_panel.setVisible(false);
        addMemberPanel.setVisible(false);
        removeMemberPanel.setVisible(false);
        admin_employee_panel.setVisible(false);
        addEmployeePanel.setVisible(false);
        setTextFieldsNull();
    }

    public void open_add_member_panel(){
        admin_slide_x = -140;
        adminMembersPanel.setVisible(false);
        addMemberPanel.setVisible(true);
    }

    public void open_removeMemberPanel(){
        adminMembersPanel.setVisible(false);
        admin_slide_x = -140;
        repaint();
        removeMemberPanel.setVisible(true);
    }

    public void setTextFieldsNull(){
        admin_update_name_textfield.setText("");
        admin_update_key_textfield.setText("");
        admin_update_new_key_textfield.setText("");
        remove_member_username_textfield.setText("");
        admin_key_textfield.setText("");
        add_member_name_textfield.setText("");
        add_member_username_textfield.setText("");
        add_member_password_textfield.setText("");
        add_member_age_textfield.setText("");
        add_member_phone_textfield.setText("");
        add_member_email_textfield.setText("");
        search_member_textfield.setText("");
        add_employee_name_textfield.setText("");
        add_employee_username_textfield.setText("");
        add_employee_password_textfield.setText("");
        add_employee_age_textfield.setText("");
        add_employee_job_textfield.setText("");
        add_employee_phone_textfield.setText("");
        add_employee_email_textfield.setText("");
    }

    public void open_viewMembersPanel(){
        adminMembersPanel.setVisible(false);
        admin_slide_x = -140;
        repaint();
        viewMembersPanel = new ViewMembersPanel();
        this.add(viewMembersPanel);
        viewMembersPanel.setVisible(true);
        vmp_scroll_up.setVisible(true);
        vmp_scroll_down.setVisible(true);
        vmp_scroll_right.setVisible(true);
        vmp_scroll_left.setVisible(true);
        search_member.setVisible(true);
        admin_employee_panel.setVisible(false);
        viewAMemberPanel.setVisible(false);
    }

    public void exit_viewMembersPanel(){
        viewMembersPanel.setVisible(false);
        vmp_scroll_up.setVisible(false);
        vmp_scroll_down.setVisible(false);
        vmp_scroll_right.setVisible(false);
        vmp_scroll_left.setVisible(false);
        search_member.setVisible(false);
        search_panel.setVisible(false);
        viewAMemberPanel.setVisible(false);
    }

    public void openViewAMemberPanel(){
        vmp_scroll_up.setVisible(false);
        vmp_scroll_down.setVisible(false);
        vmp_scroll_right.setVisible(false);
        vmp_scroll_left.setVisible(false);
        viewMembersPanel.setVisible(false);
        viewAMemberPanel.setVisible(true);
        setTextFieldsNull();
    }

    public void openAdminEmployeesPanel(){
        admin_slide_x = -140;
        repaint();
        admin_home_page_panel.setVisible(false);
        admin_settings_button.setVisible(true);
        addMemberPanel.setVisible(false);
        admin_info_panel.setVisible(false);
        adminMembersPanel.setVisible(false);
        removeMemberPanel.setVisible(false);
        admin_employee_panel.setVisible(true);
        addEmployeePanel.setVisible(false);
        exit_viewMembersPanel();
        setTextFieldsNull();
    }

    public void openAddEmployeePanel(){
        admin_slide_x = -140;
        repaint();
        admin_employee_panel.setVisible(false);
        addEmployeePanel.setVisible(true);
    }

    public void search(String username_input){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?useSSL=false", "root", "abdularham123");
            Statement stm = con.createStatement();
            ResultSet rs = stm.executeQuery("select * from members");
            boolean user_found = false;
            while (rs.next()){
                if(rs.getString(1).equals(username_input)){
                    user_found = true;
                }else if (rs.getString(3).equals(username_input)){
                    user_found = true;
                    username_input = rs.getString(1);
                }
            }
            con.close();
            if (!user_found){
                new UserNotExist();
            }else{
                viewAMemberPanel.getMember(username_input);
                openViewAMemberPanel();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public void actionPerformed(ActionEvent e){
        if (admin_settings_sliding){
            admin_slide_x += 20;
            repaint();
        }if (admin_slide_x==0){
            admin_settings_sliding = false;
        }if (admin_settings_reverse_sliding){
            repaint();
            admin_slide_x -= 20;
        }if (admin_slide_x==-140){
            admin_settings_reverse_sliding = false;
        }if (shifting_in_admin_account) {
            repaint();
            admin_slide_x -= 140;
            shifting_in_admin_account = false;
        }if (e.getSource()==admin_login_button){
            admin_login();
        }if (e.getSource()==show_hide_admin_key){
            if (admin_key_visible){
                admin_key_textfield.setEchoChar('●');
                show_hide_admin_key.setIcon(icon3);
                admin_key_visible = false;
            }else{
                admin_key_textfield.setEchoChar((char)0);
                show_hide_admin_key.setIcon(icon4);
                admin_key_visible = true;
            }
        }
        if (e.getSource()==admin_settings_button){
            if (admin_slide_x==-140){
                admin_settings_sliding = true;
            }else if (admin_slide_x==0){
                admin_settings_reverse_sliding = true;
            }
        }if (e.getSource()==refresh_admin_page){
            open_admin_account();
        }if (e.getSource()==admin_info_key_show_hide_button){
            if (admin_key_info_visible){
                admin_key_info_visible = false;
                admin_info_key_show_hide_button.setIcon(icon1);
                admin_update_key_textfield.setEchoChar('●');
            }else {
                admin_key_info_visible = true;
                admin_info_key_show_hide_button.setIcon(icon2);
                admin_update_key_textfield.setEchoChar((char)0);
            }
        }if (e.getSource()==admin_info_new_key_show_hide_button){
            if (admin_new_key_visible){
                admin_new_key_visible = false;
                admin_info_new_key_show_hide_button.setIcon(icon1);
                admin_update_new_key_textfield.setEchoChar('●');
            }else{
                admin_new_key_visible = true;
                admin_info_new_key_show_hide_button.setIcon(icon2);
                admin_update_new_key_textfield.setEchoChar((char)0);
            }
        }if (e.getSource()==admin_info_update){
            new UpdateAdminCredentials(admin_update_name_textfield.getText(), String.valueOf(admin_update_key_textfield.getPassword()), String.valueOf(admin_update_new_key_textfield.getPassword()));
        }if (e.getSource()==admin_add_member){
            open_add_member_panel();
        }if (e.getSource()==add_member_button){
            CheckMemberFields checkMemberFields = new CheckMemberFields();
            String name = add_member_name_textfield.getText();
            String username = add_member_username_textfield.getText();
            String password = add_member_password_textfield.getText();
            String gender = String.valueOf(add_member_gender_combobox.getSelectedItem());
            String age = add_member_age_textfield.getText();
            String phone_number = add_member_phone_textfield.getText();
            String email_address = add_member_email_textfield.getText();
            checkMemberFields.check(name, username, password, gender, age, phone_number, email_address);
        }if (e.getSource()==admin_remove_member){
            open_removeMemberPanel();
        }if (e.getSource()==remove_member_button){
            RemoveMember removeMember = new RemoveMember();
            removeMember.check_password(remove_member_username_textfield.getText());
        }if (e.getSource()==admin_view_members){
            open_viewMembersPanel();
        }if (e.getSource()==vmp_scroll_right){
            viewMembersPanel.scroll_right();
        }if (e.getSource()==vmp_scroll_left){
            viewMembersPanel.scroll_left();
        }if (e.getSource()==vmp_scroll_up){
            viewMembersPanel.scroll_up();
        }if (e.getSource()==vmp_scroll_down){
            viewMembersPanel.scroll_down();
        }if (e.getSource()==search_member){
            if (!searching_member){
                search_panel.setVisible(true);
                searching_member = true;
            }else{
                searching_member = false;
                search_panel.setVisible(false);
                if (search_member_textfield.getText().length()>0){
                    search(search_member_textfield.getText());
                }
            }
        }if (e.getSource()==back_from_vamp){
            open_viewMembersPanel();
        }if (e.getSource()==admin_add_employee){
            openAddEmployeePanel();
        }if (e.getSource()==add_employee_button){
            CheckEmployeeFields checkEmployeeFields = new CheckEmployeeFields();
            String employee_username = add_employee_username_textfield.getText();
            String employee_password = add_employee_password_textfield.getText();
            String employee_name = add_employee_name_textfield.getText();
            String employee_age = add_employee_age_textfield.getText();
            String employee_gender = String.valueOf(add_employee_gender_combobox.getSelectedItem());
            String employee_job = add_employee_job_textfield.getText();
            String employeee_phone = add_employee_phone_textfield.getText();
            String employee_email = add_employee_email_textfield.getText();
            checkEmployeeFields.check(employee_name, employee_username, employee_password, employee_gender, employee_age, employee_job, employeee_phone, employee_email);
        }
    }

   public void mousePressed(MouseEvent e) {
        if (admin_slide_x==0 && e.getX()<141){
            if (e.getY()>60 && e.getY()<90){
                open_admin_account();
            }
            else if (e.getY()>90 && e.getY()<120){
                openAdminEmployeesPanel();
            }else if (e.getY()>120 && e.getY()<150){
                open_admin_members_panel();
            }else if (e.getY()>150 && e.getY()<180){
                move_to_admin_info_update();
            }else if (e.getY()>180 && e.getY()<210){
                logout_admin_account();
            }
        }if (admin_home_page_panel.isVisible()){
            if (e.getX()>400 && e.getX()<600 && e.getY()>100 && e.getY()<250){
                new AdminProfileSetFrame();
            }
        }
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {
    }
    public void mouseClicked(MouseEvent e){
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode()==KeyEvent.VK_ENTER){
            System.out.println("Enter");
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}
