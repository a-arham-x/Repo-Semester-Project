package com;

public class AddMemberPanel extends AdminMembersPanel{
    AddMemberPanel(){
        this.setBounds(150, 50, 700, 500);
    }
}
