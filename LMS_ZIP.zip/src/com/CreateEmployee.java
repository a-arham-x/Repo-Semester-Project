package com;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CreateEmployee {

    public void add_employee_to_database(String username, String password, String name, String gender, int age, String job, String phone_number, String email){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library?useSSL=false", "root", "abdularham123");
            String sql = "INSERT INTO employees VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStmt = con.prepareStatement(sql);
            preparedStmt.setString(1, username);
            preparedStmt.setString(2, password);
            preparedStmt.setString(3, name);
            preparedStmt.setString(4,gender);
            preparedStmt.setInt(5, age);
            preparedStmt.setString(6, job);
            preparedStmt.setString(7, email);
            preparedStmt.setString(8, phone_number);
            File empty_pic = new File("EmptyProfilePic.png");
            FileInputStream profile_file = new FileInputStream(empty_pic);
            preparedStmt.setBlob(9, profile_file);
            preparedStmt.execute();
            con.close();
            new MemberAdded();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
