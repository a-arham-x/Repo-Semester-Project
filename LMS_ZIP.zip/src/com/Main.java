package com;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JFrame implements ActionListener, MouseListener{
    LoginWindowPanel loginWindowPanel;
    LargeLabel openning_label;
    ProjectTextfield username_login_textfield;
    JPasswordField password_login_textfield;
    SmallButton loginButton;
    JButton show_hide_login_password;
    ImageIcon icon1;
    ImageIcon icon2;
    JButton settings_button;
    boolean password_visible = false;
    Timer timer;
    boolean sliding = false;
    boolean reverse_sliding = false;
    boolean not_logged_in = true;
    int slide_x=-140;
    int label_x = 145;
    boolean shifting_page = false;
    CreditsPanel creditsPanel;
    AboutPanel aboutPanel;
    Main(){
        this.setSize(1000, 670);
        this.addMouseListener(this);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Color.white);

        settings_button = new JButton("⁞");
        settings_button.addActionListener(this);
        settings_button.setFocusable(false);
        settings_button.setBackground(new Color(148, 0, 211));
        settings_button.setForeground(Color.white);
        settings_button.setFont(new Font("Arial", Font.BOLD, 15));
        settings_button.setBounds(0, 0, 40, 40);
        this.add(settings_button);

        loginWindowPanel = new LoginWindowPanel();
        this.add(loginWindowPanel);

        openning_label = new LargeLabel("Library Management System", label_x, 20);
        this.add(openning_label);

        username_login_textfield = new ProjectTextfield(185, 150);
        loginWindowPanel.add(username_login_textfield);

        password_login_textfield = new JPasswordField();
        password_login_textfield.setFont(new Font("Arial", Font.PLAIN, 20));
        password_login_textfield.setBounds(185, 250, 300, 30);
        password_login_textfield.setEchoChar('●');
        loginWindowPanel.add(password_login_textfield);

        loginButton = new SmallButton("LogIn", 285, 310);
        loginWindowPanel.add(loginButton);

        icon1 = new ImageIcon("eyes to be used (2).png");
        icon2 = new ImageIcon("eyes to be used (3).png");
        show_hide_login_password = new JButton();
        show_hide_login_password.setIcon(icon1);
        show_hide_login_password.setForeground(Color.white);
        show_hide_login_password.addActionListener(this);
        show_hide_login_password.setFocusable(false);
        show_hide_login_password.setBounds(485, 250, 30, 30);
        loginWindowPanel.add(show_hide_login_password);

        creditsPanel = new CreditsPanel();
        this.add(creditsPanel);
        creditsPanel.setVisible(false);

        aboutPanel = new AboutPanel();
        this.add(aboutPanel);
        aboutPanel.setVisible(false);

        this.setVisible(true);

        timer = new Timer(20, this);
        timer.start();
    }

    public static void main(String[] args) {
        new Main();
    }

    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.setPaint(new Color(148, 0, 211));
        g2D.drawRect(slide_x, 75, 140, 600);
        g2D.fillRect(slide_x, 70, 140, 600);
        g2D.setPaint(Color.white);
        g2D.setFont(new Font("Arial", Font.BOLD, 20));
        g2D.drawString("About", slide_x+20, 90);
        g2D.drawString("LogIn", slide_x + 20, 120);
        g2D.drawString("Credits", slide_x+20, 150);
    }

    public void move_to_login_page(){
        if (slide_x==0){
            shifting_page = true;
        }
        aboutPanel.setVisible(false);
        creditsPanel.setVisible(false);
        openning_label.setVisible(true);
        loginWindowPanel.setVisible(true);
    }

    public void open_creditsPanel(){
        creditsPanel.setVisible(true);
        shifting_page = true;
        aboutPanel.setVisible(false);
        loginWindowPanel.setVisible(false);
        openning_label.setVisible(false);
        username_login_textfield.setText("");
        password_login_textfield.setText("");

    }

    public void open_aboutPanel(){
        aboutPanel.setVisible(true);
        creditsPanel.setVisible(false);
        shifting_page = true;
        loginWindowPanel.setVisible(false);
        openning_label.setVisible(false);
        username_login_textfield.setText("");
        password_login_textfield.setText("");
    }


    public void actionPerformed(ActionEvent e){
        if (sliding){
            repaint();
            slide_x += 20;
        }if (slide_x>-1){
            sliding = false;
        }if (reverse_sliding){
            repaint();
            slide_x -= 20;
        }if (slide_x==-140){
            reverse_sliding = false;}
        if (shifting_page){
            repaint();
            slide_x -= 140;
            shifting_page = false;
        }if (e.getSource()==show_hide_login_password){
            if (password_visible){
                show_hide_login_password.setIcon(icon1);
                password_login_textfield.setEchoChar('●');
                password_visible = false;
            }else {
                show_hide_login_password.setIcon(icon2);
                password_login_textfield.setEchoChar((char) 0);
                password_visible = true;
            }
        }if (e.getSource()==settings_button){
            if (not_logged_in) {
                if (slide_x==-140){
                    sliding = true;
                }else if (slide_x==0){
                    reverse_sliding = true;
                }
            }
        }
    }

    public void mousePressed(MouseEvent e) {
        if (slide_x>-1 && e.getX()<141){
            if (e.getY()>60 && e.getY()<90){
                open_aboutPanel();
            }else if (e.getY()>90 && e.getY()<120){
                move_to_login_page();
            }else if (e.getY()>120 && e.getY()<150){
                open_creditsPanel();
            }
        }
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {
    }
    public void mouseClicked(MouseEvent e){
    }
}
