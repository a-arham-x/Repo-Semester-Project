package com;

public interface UniqueUsername {
    boolean unique_username(String username);
}
